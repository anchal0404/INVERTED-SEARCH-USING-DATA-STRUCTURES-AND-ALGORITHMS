#include "inverted_search.h"

int main(int argc , char *argv[])
{
    system("clear");

    Wlist *head[27] = {NULL};

    //validate CLA
    if(argc <= 1)
    {
	printf("ENter the valid no. arg\n");
	printf("./Slist.exe file1.txt  file2.txt.....\n");
	return 0;
    }

    //create file linked list
    //declare head pointer

    Flist *f_head = NULL;

    //validate the file 

    file_validation_n_file_list(&f_head , argv);

    if(f_head == NULL)
    {
	printf("No files available in the linked list\n");
	printf("Hence the process terminated\n");
	return 1;
    }

	int choice;
	char option;
	do{
		printf("Select you choice among following options:\n1. Create Database\n2. Display Database\n3. Update Databse\n4. Search\n5. Save Database\nEnter your choice: ");
		scanf("%d",&choice);
		
		switch(choice)
		{
    //Create Database
		case 1:
    		create_database(f_head , head);
			break;
    //Display database 
		case 2:
    		display_database(head);
			break;
   //Update_database
		case 3:
   	 		update_database(head , &f_head);
			break;
	//Search data
		case 4:
    		char word[WORD_SIZE]; 
    		printf("Enter the search word\n");
    		scanf("%s" , word);
			search(head[tolower(word[0]) % 97] , word);
			break;
    //Save database
		case 5:
    		save_database(head);
			break;
		default:
			break;
		}
	printf("Do you want to continue (y/n): ");
	getchar();
	scanf("%c",&option);
	}while(option == 'Y' || option == 'y');
}

