#include "inverted_search.h"
void update_database( Wlist *head[], Flist **f_head)
{
    //prompt the user for new file name to update the database

	int empty;
    char fname[FNAME_SIZE];
    printf("Enter the file name you want to add in Database:\n"); 
    scanf("%s" , fname);

    //validate 
    //........TODO.........

	empty = isFileEmpty(fname);
	if(empty == FILE_NOTAVAILABLE)
	{
		printf("The file %s is not available\n",fname);
		printf("Hence we are not adding %s into File Linked List\n",fname);
		return;
	}
	else
	{
		int result = to_create_list_of_files(f_head,fname);
		if(result == SUCCESS)
		{
			printf("Successful in inserting File %s into the File Linked List\n",fname);
		}
		else if(result == REPEATATION)
		{
			printf("This file %s is Repeated\n",fname);
			printf("Hence we are not adding %s itno file linked List\n",fname);
			return;
		}
		else
		{
			printf("Failed to add the file into the File Linked List\n");
			return;
		}
	}
	Flist* ftemp = *f_head;
	while(ftemp)
    {
	if(!strcmp(ftemp->file_name , fname))
	{
	    create_database(ftemp , head);
	}
    ftemp =(ftemp->link);
    }
}


