#include "inverted_search.h"

void save_database(Wlist *head[])
{
    //prompt the user
    char file_name[FNAME_SIZE];

    printf("Enter the file name to save the database\n");
    scanf("%s" , file_name);

    //open the file in write mode

    FILE *fptr = fopen(file_name , "w");

	if(fptr == NULL)
	{
		printf("Error: File not available\n");
		return;
	}

    fprintf(fptr,"[index]  word is [word] : file count is [file_count file/s : file is [file_name] : word count is [word_count\n");
	fprintf(fptr,"\n------------------------------------------------\n");
    for(int i = 0; i < 27; i++)
    {
		Wlist* temp = head[i];
		while(temp != NULL)
		{
			fprintf(fptr,"[%d] [%s] %d files:\t",i,temp->word,temp->file_count);
			Ltable* ltemp = temp->Tlink;
			while(ltemp != NULL)
			{
				fprintf(fptr,"%s %d\t",ltemp->file_name,ltemp->word_count);
				ltemp = ltemp->table_link;
			}
			fprintf(fptr,"\n");
			temp = temp->link;
		}
    }
	fprintf(fptr,"\n---------------------------------------------\n");
    printf("Database saved successfully in %s\n",file_name);
	fclose(fptr);
}




