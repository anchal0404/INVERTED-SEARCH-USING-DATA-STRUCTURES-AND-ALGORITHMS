#include "inverted_search.h"

void search( Wlist *head, char *word)
{
    // check empty or not

    if(head == NULL)
    {
		printf("List is empty , search not possible\n");
		return ;
    }


    //traverse
    while(head)
    {
	//compare the words
		if(!(strcmp(head->word , word)))
		{
	    	printf("Word %s is present in %d file\n" , word , head->file_count);
	    	Ltable *Thead = head->Tlink;
	    	while(Thead)
	    	{
				printf("In file : %s\t%d  times \n" , Thead->file_name , Thead->word_count);
				Thead=Thead->table_link;
	    	}
	    	return;
		}
		head=head->link;
    }
	printf("Error:Search word not found in the list\n");

}


