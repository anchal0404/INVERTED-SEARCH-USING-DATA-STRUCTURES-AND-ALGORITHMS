#include "inverted_search.h"
char *fname;
void create_database(Flist *f_head, Wlist *head[])
{
    //traverse through the file linked list 

    while(f_head)
    {
	read_datafile(f_head , head , f_head->file_name);
	f_head=f_head->link;
	
    }
}

Wlist * read_datafile(Flist *file, Wlist *head[], char *filename)
{
    //open the file in read mode

    FILE *fptr = fopen(filename , "r" );

    fname = filename;
    int flag = 1;
    
    //declare an array to store the words

    char word[WORD_SIZE];

    while(fscanf(fptr ,"%s" , word ) != EOF )
    {
	//INDEX
	int index = tolower(word[0]) % 97;

	//other alphabets 
	if( !(index >= 0 && index <= 25))
	    index = 26;

	if(head[index] != NULL)
	{
	    Wlist *temp = head[index];
	    //compare the words at each node with new word

	    while(temp)
	    {
			if(! strcmp(temp->word , word))
			{
		    	update_word_count(&temp,filename);
		    	flag = 0;
		    	break;
			}
			temp = temp->link;
	    }
	}
	if (flag == 1)
	{
		//if words are not reeated
		insert_at_last(&head[index] , word);
	}
	}
	printf("Successfully created database for %s file\n",filename);
}
int update_word_count(Wlist **head , char *file_name)
{
    //....TODO.....
    //cheack filenames are same or not
    // if file names are same , increment word_count
    // if file names are diff , increment file count , create ltable
	Ltable *ltemp = (*head)->Tlink,*prev = NULL;
	while(ltemp)
	{
		if(!strcmp(ltemp->file_name,file_name))
		{
			ltemp->word_count++;
			return SUCCESS;
		}
		prev = ltemp;
		ltemp = ltemp->table_link;
	}
	(*head)->file_count++;
	Ltable* new_ltable_node = malloc(sizeof(Ltable));
	if(new_ltable_node==NULL)
		return FAILURE;

	strcpy(new_ltable_node->file_name,file_name);
	new_ltable_node->word_count=1;
	new_ltable_node->table_link=NULL;
	prev->table_link = new_ltable_node;
	return SUCCESS;
}




